##Using the Xgboost algorithm to analyze the influencing factors of soil respiration in China's terrestrial ecosystems in response to extreme drought drought
install.packages("xgboost")
install.packages("Matrix")
install.packages("survival")
install.packages("caret")
install.packages("ModelMetrics")
install.packages("caTools")
install.packages("cvms")
install.packages("RColorBrewer")


library(readr)
library(dplyr)
library(xgboost)
library(Matrix)
library(survival)
library(caret)
library(caTools)
library(cvms)
library(RColorBrewer)
library(ggplot2)

RS <- read_csv("E:\\RP\\Data of influencing factors of soil respiration in China's terrestrial ecosystems.csv")
glimpse(RS , width = 40)

mydata <- RS %>% filter(Vegetation == "forests" & ED == "0")
glimpse(mydata, width = 40)

#split into training (70%) and testing set (70%)

sample_split <- sample.split(Y = mydata$RS, SplitRatio = 0.7)
train_set <- subset(x = mydata, sample_split == TRUE)
test_set <- subset(x = mydata, sample_split == FALSE)


#define predictor and response variables in training dataset
y_train <- train_set$RS
glimpse(y_train, width = 40)
x_train <- train_set %>% select(1:21)
glimpse(x_train, width = 40)


y_test <- test_set$RS
glimpse(y_test, width = 40)
x_test <- test_set %>% select(1:21)
glimpse(x_test, width = 40)


xgb_train = xgb.DMatrix(as.matrix(sapply(x_train, as.numeric)), label=y_train)
xgb_test = xgb.DMatrix(as.matrix(sapply(x_test, as.numeric)), label=y_test)

watchlist = list(train=xgb_train, test=xgb_test)

model = xgb.train(data = xgb_train, max.depth = 3, watchlist=watchlist, nrounds = 70)

final = xgboost(data = xgb_train, max.depth = 3, nrounds = 56, verbose = 0)

final


importance_matrix <- xgb.importance(feature_names = colnames(xgb_train), model = final)
importance_matrix

xgb.plot.importance(importance_matrix)


data<-as.data.frame(importance_matrix)

coul <- brewer.pal(4, "PuOr") 
coul <- colorRampPalette(coul)(21)


p<-ggplot(data=data,mapping=aes(x=reorder(Feature,Gain),y=Gain/0.4654292279,fill=Feature)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + coord_flip()+ xlab("Variable") + ylab("Variable relative importance") + theme_bw() + scale_fill_manual(values=c("#E66101","#E96E0F", "#EC7B1E", "#F0882D", "#F3953B", "#F7A24A", "#FAAF59", "#F9B768", "#EEB579", "#E2B389", "#E2B389", "#D7B19A" , "#CCAFAB",  "#C0ADBB", "#B5ABCC", "#A99FCC", "#9C8FC3", "#907EBB", "#836DB2", "#775DAA", "#6A4CA1", "#5E3C99"))

p

p+theme(text=element_text(size=12,  family="serif"))


p + theme(axis.title.x =element_text(size=14, family="serif", color = "black", hjust=0.5), axis.title.y=element_text(size=14,family="serif", color = "black", hjust=0.5),axis.text=element_text(size=14,family="serif", color = "black", hjust=0.5))





mydata <- RS %>% filter(Vegetation == "forests" & ED == "1")
glimpse(mydata, width = 40)

#split into training (70%) and testing set (70%)

sample_split <- sample.split(Y = mydata$RS, SplitRatio = 0.7)
train_set <- subset(x = mydata, sample_split == TRUE)
test_set <- subset(x = mydata, sample_split == FALSE)


#define predictor and response variables in training dataset
y_train <- train_set$RS
glimpse(y_train, width = 40)
x_train <- train_set %>% select(1:21)
glimpse(x_train, width = 40)


y_test <- test_set$RS
glimpse(y_test, width = 40)
x_test <- test_set %>% select(1:21)
glimpse(x_test, width = 40)


xgb_train = xgb.DMatrix(as.matrix(sapply(x_train, as.numeric)), label=y_train)
xgb_test = xgb.DMatrix(as.matrix(sapply(x_test, as.numeric)), label=y_test)

watchlist = list(train=xgb_train, test=xgb_test)

model = xgb.train(data = xgb_train, max.depth = 3, watchlist=watchlist, nrounds = 70)

final = xgboost(data = xgb_train, max.depth = 3, nrounds = 56, verbose = 0)

final


importance_matrix <- xgb.importance(feature_names = colnames(xgb_train), model = final)
importance_matrix

xgb.plot.importance(importance_matrix)


data<-as.data.frame(importance_matrix)

coul <- brewer.pal(4, "PuOr") 
coul <- colorRampPalette(coul)(21)


p<-ggplot(data=data,mapping=aes(x=reorder(Feature,Gain),y=Gain,fill=Feature)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + coord_flip() + xlab("Variable") + ylab("Variable relative importance") + theme_bw() + scale_fill_manual(values=c("#E66101","#E96E0F", "#EC7B1E", "#F0882D", "#F3953B", "#F7A24A", "#FAAF59", "#F9B768", "#EEB579", "#E2B389", "#E2B389", "#D7B19A" , "#CCAFAB",  "#C0ADBB", "#B5ABCC", "#A99FCC", "#9C8FC3", "#907EBB", "#836DB2", "#775DAA", "#6A4CA1", "#5E3C99"))

p

p + theme(axis.title.x =element_text(size=14, family="serif", color = "black", hjust=0.5), axis.title.y=element_text(size=14,family="serif", color = "black", hjust=0.5),axis.text=element_text(size=14,family="serif", color = "black", hjust=0.5)) + guides(fill=FALSE)





mydata <- RS %>% filter(Vegetation == "grasslands" & ED == "0")
glimpse(mydata, width = 40)

#split into training (70%) and testing set (70%)

sample_split <- sample.split(Y = mydata$RS, SplitRatio = 0.7)
train_set <- subset(x = mydata, sample_split == TRUE)
test_set <- subset(x = mydata, sample_split == FALSE)


#define predictor and response variables in training dataset
y_train <- train_set$RS
glimpse(y_train, width = 40)
x_train <- train_set %>% select(1:21)
glimpse(x_train, width = 40)


y_test <- test_set$RS
glimpse(y_test, width = 40)
x_test <- test_set %>% select(1:21)
glimpse(x_test, width = 40)


xgb_train = xgb.DMatrix(as.matrix(sapply(x_train, as.numeric)), label=y_train)
xgb_test = xgb.DMatrix(as.matrix(sapply(x_test, as.numeric)), label=y_test)

watchlist = list(train=xgb_train, test=xgb_test)

model = xgb.train(data = xgb_train, max.depth = 3, watchlist=watchlist, nrounds = 70)

final = xgboost(data = xgb_train, max.depth = 3, nrounds = 56, verbose = 0)

final


importance_matrix <- xgb.importance(feature_names = colnames(xgb_train), model = final)
importance_matrix

xgb.plot.importance(importance_matrix)


data<-as.data.frame(importance_matrix)

coul <- brewer.pal(4, "PuOr") 
coul <- colorRampPalette(coul)(21)


p<-ggplot(data=data,mapping=aes(x=reorder(Feature,Gain),y=Gain/0.2475164374,fill=Feature)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + coord_flip() + ylab("Variable relative importance") + theme_bw() + scale_fill_manual(values=c("#E66101","#E96E0F", "#EC7B1E", "#F0882D", "#F3953B", "#F7A24A", "#FAAF59", "#F9B768", "#EEB579", "#E2B389", "#E2B389", "#D7B19A" , "#CCAFAB",  "#C0ADBB", "#B5ABCC", "#A99FCC", "#9C8FC3", "#907EBB", "#836DB2", "#775DAA", "#6A4CA1", "#5E3C99"))

p





mydata <- RS %>% filter(Vegetation == "grasslands" & ED == "1")
glimpse(mydata, width = 40)

#split into training (70%) and testing set (70%)

sample_split <- sample.split(Y = mydata$RS, SplitRatio = 0.7)
train_set <- subset(x = mydata, sample_split == TRUE)
test_set <- subset(x = mydata, sample_split == FALSE)


#define predictor and response variables in training dataset
y_train <- train_set$RS
glimpse(y_train, width = 40)
x_train <- train_set %>% select(1:21)
glimpse(x_train, width = 40)


y_test <- test_set$RS
glimpse(y_test, width = 40)
x_test <- test_set %>% select(1:21)
glimpse(x_test, width = 40)


xgb_train = xgb.DMatrix(as.matrix(sapply(x_train, as.numeric)), label=y_train)
xgb_test = xgb.DMatrix(as.matrix(sapply(x_test, as.numeric)), label=y_test)

watchlist = list(train=xgb_train, test=xgb_test)

model = xgb.train(data = xgb_train, max.depth = 3, watchlist=watchlist, nrounds = 70)

final = xgboost(data = xgb_train, max.depth = 3, nrounds = 56, verbose = 0)

final


importance_matrix <- xgb.importance(feature_names = colnames(xgb_train), model = final)
importance_matrix

xgb.plot.importance(importance_matrix)


data<-as.data.frame(importance_matrix)

coul <- brewer.pal(4, "PuOr") 
coul <- colorRampPalette(coul)(21)


p<-ggplot(data=data,mapping=aes(x=reorder(Feature,Gain),y=Gain,fill=Feature)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + coord_flip() + xlab("Variable") + ylab("Variable relative importance") + theme_bw() + scale_fill_manual(values=c("#E66101","#E96E0F", "#EC7B1E", "#F0882D", "#F3953B", "#F7A24A", "#FAAF59", "#F9B768", "#EEB579", "#E2B389", "#E2B389", "#D7B19A" , "#CCAFAB",  "#C0ADBB", "#B5ABCC", "#A99FCC", "#9C8FC3", "#907EBB", "#836DB2", "#775DAA", "#6A4CA1", "#5E3C99"))

p

p + theme(axis.title.x =element_text(size=14, family="serif", color = "black", hjust=0.5), axis.title.y=element_text(size=14,family="serif", color = "black", hjust=0.5),axis.text=element_text(size=14,family="serif", color = "black", hjust=0.5)) + guides(fill=FALSE)




mydata <- RS %>% filter(Vegetation == "croplands" & ED == "0")
glimpse(mydata, width = 40)

#split into training (70%) and testing set (70%)

sample_split <- sample.split(Y = mydata$RS, SplitRatio = 0.7)
train_set <- subset(x = mydata, sample_split == TRUE)
test_set <- subset(x = mydata, sample_split == FALSE)


#define predictor and response variables in training dataset
y_train <- train_set$RS
glimpse(y_train, width = 40)
x_train <- train_set %>% select(1:21)
glimpse(x_train, width = 40)


y_test <- test_set$RS
glimpse(y_test, width = 40)
x_test <- test_set %>% select(1:21)
glimpse(x_test, width = 40)


xgb_train = xgb.DMatrix(as.matrix(sapply(x_train, as.numeric)), label=y_train)
xgb_test = xgb.DMatrix(as.matrix(sapply(x_test, as.numeric)), label=y_test)

watchlist = list(train=xgb_train, test=xgb_test)

model = xgb.train(data = xgb_train, max.depth = 3, watchlist=watchlist, nrounds = 70)

final = xgboost(data = xgb_train, max.depth = 3, nrounds = 56, verbose = 0)

final


importance_matrix <- xgb.importance(feature_names = colnames(xgb_train), model = final)
importance_matrix

xgb.plot.importance(importance_matrix)


data<-as.data.frame(importance_matrix)

coul <- brewer.pal(4, "PuOr") 
coul <- colorRampPalette(coul)(21)


p<-ggplot(data=data,mapping=aes(x=reorder(Feature,Gain),y=Gain/0.273249255,fill=Feature)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + coord_flip() + ylab("Variable relative importance") + theme_bw() + scale_fill_manual(values=c("#E66101","#E96E0F", "#EC7B1E", "#F0882D", "#F3953B", "#F7A24A", "#FAAF59", "#F9B768", "#EEB579", "#E2B389", "#E2B389", "#D7B19A" , "#CCAFAB",  "#C0ADBB", "#B5ABCC", "#A99FCC", "#9C8FC3", "#907EBB", "#836DB2", "#775DAA", "#6A4CA1", "#5E3C99"))

p







mydata <- RS %>% filter(Vegetation == "croplands" & ED == "1")
glimpse(mydata, width = 40)

#split into training (70%) and testing set (70%)

sample_split <- sample.split(Y = mydata$RS, SplitRatio = 0.7)
train_set <- subset(x = mydata, sample_split == TRUE)
test_set <- subset(x = mydata, sample_split == FALSE)


#define predictor and response variables in training dataset
y_train <- train_set$RS
glimpse(y_train, width = 40)
x_train <- train_set %>% select(1:21)
glimpse(x_train, width = 40)


y_test <- test_set$RS
glimpse(y_test, width = 40)
x_test <- test_set %>% select(1:21)
glimpse(x_test, width = 40)


xgb_train = xgb.DMatrix(as.matrix(sapply(x_train, as.numeric)), label=y_train)
xgb_test = xgb.DMatrix(as.matrix(sapply(x_test, as.numeric)), label=y_test)

watchlist = list(train=xgb_train, test=xgb_test)

model = xgb.train(data = xgb_train, max.depth = 3, watchlist=watchlist, nrounds = 70)

final = xgboost(data = xgb_train, max.depth = 3, nrounds = 56, verbose = 0)

final


importance_matrix <- xgb.importance(feature_names = colnames(xgb_train), model = final)
importance_matrix

xgb.plot.importance(importance_matrix)


data<-as.data.frame(importance_matrix)

coul <- brewer.pal(4, "PuOr") 
coul <- colorRampPalette(coul)(21)


p<-ggplot(data=data,mapping=aes(x=reorder(Feature,Gain),y=Gain,fill=Feature)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + coord_flip() + xlab("Variable") + ylab("Variable relative importance") + theme_bw() + scale_fill_manual(values=c("#E66101","#E96E0F", "#EC7B1E", "#F0882D", "#F3953B", "#F7A24A", "#FAAF59", "#F9B768", "#EEB579", "#E2B389", "#E2B389", "#D7B19A" , "#CCAFAB",  "#C0ADBB", "#B5ABCC", "#A99FCC", "#9C8FC3", "#907EBB", "#836DB2", "#775DAA", "#6A4CA1", "#5E3C99"))

p

p + theme(axis.title.x =element_text(size=14, family="serif", color = "black", hjust=0.5), axis.title.y=element_text(size=14,family="serif", color = "black", hjust=0.5),axis.text=element_text(size=14,family="serif", color = "black", hjust=0.5)) + guides(fill=FALSE)











mydata <- RS %>% filter(Vegetation == "savannas" & ED == "0")
glimpse(mydata, width = 40)

#split into training (70%) and testing set (70%)

sample_split <- sample.split(Y = mydata$RS, SplitRatio = 0.7)
train_set <- subset(x = mydata, sample_split == TRUE)
test_set <- subset(x = mydata, sample_split == FALSE)


#define predictor and response variables in training dataset
y_train <- train_set$RS
glimpse(y_train, width = 40)
x_train <- train_set %>% select(1:21)
glimpse(x_train, width = 40)


y_test <- test_set$RS
glimpse(y_test, width = 40)
x_test <- test_set %>% select(1:21)
glimpse(x_test, width = 40)


xgb_train = xgb.DMatrix(as.matrix(sapply(x_train, as.numeric)), label=y_train)
xgb_test = xgb.DMatrix(as.matrix(sapply(x_test, as.numeric)), label=y_test)

watchlist = list(train=xgb_train, test=xgb_test)

model = xgb.train(data = xgb_train, max.depth = 3, watchlist=watchlist, nrounds = 70)

final = xgboost(data = xgb_train, max.depth = 3, nrounds = 56, verbose = 0)

final


importance_matrix <- xgb.importance(feature_names = colnames(xgb_train), model = final)
importance_matrix

xgb.plot.importance(importance_matrix)


data<-as.data.frame(importance_matrix)

coul <- brewer.pal(4, "PuOr") 
coul <- colorRampPalette(coul)(21)


p<-ggplot(data=data,mapping=aes(x=reorder(Feature,Gain),y=Gain/4.906835e-01,fill=Feature)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + coord_flip() + ylab("Variable relative importance") + theme_bw() + scale_fill_manual(values=c("#E66101","#E96E0F", "#EC7B1E", "#F0882D", "#F3953B", "#F7A24A", "#FAAF59", "#F9B768", "#EEB579", "#E2B389", "#E2B389", "#D7B19A" , "#CCAFAB",  "#C0ADBB", "#B5ABCC", "#A99FCC", "#9C8FC3", "#907EBB", "#836DB2", "#775DAA", "#6A4CA1", "#5E3C99"))

p







mydata <- RS %>% filter(Vegetation == "savannas" & ED == "1")
glimpse(mydata, width = 40)

#split into training (70%) and testing set (70%)

sample_split <- sample.split(Y = mydata$RS, SplitRatio = 0.7)
train_set <- subset(x = mydata, sample_split == TRUE)
test_set <- subset(x = mydata, sample_split == FALSE)


#define predictor and response variables in training dataset
y_train <- train_set$RS
glimpse(y_train, width = 40)
x_train <- train_set %>% select(1:21)
glimpse(x_train, width = 40)


y_test <- test_set$RS
glimpse(y_test, width = 40)
x_test <- test_set %>% select(1:21)
glimpse(x_test, width = 40)


xgb_train = xgb.DMatrix(as.matrix(sapply(x_train, as.numeric)), label=y_train)
xgb_test = xgb.DMatrix(as.matrix(sapply(x_test, as.numeric)), label=y_test)

watchlist = list(train=xgb_train, test=xgb_test)

model = xgb.train(data = xgb_train, max.depth = 3, watchlist=watchlist, nrounds = 70)

final = xgboost(data = xgb_train, max.depth = 3, nrounds = 56, verbose = 0)

final


importance_matrix <- xgb.importance(feature_names = colnames(xgb_train), model = final)
importance_matrix

xgb.plot.importance(importance_matrix)


data<-as.data.frame(importance_matrix)

coul <- brewer.pal(4, "PuOr") 
coul <- colorRampPalette(coul)(21)


p<-ggplot(data=data,mapping=aes(x=reorder(Feature,Gain),y=Gain,fill=Feature)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + coord_flip() + xlab("Variable") + ylab("Variable relative importance") + theme_bw() + scale_fill_manual(values=c("#E66101","#E96E0F", "#EC7B1E", "#F0882D", "#F3953B", "#F7A24A", "#FAAF59", "#F9B768", "#EEB579", "#E2B389", "#E2B389", "#D7B19A" , "#CCAFAB",  "#C0ADBB", "#B5ABCC", "#A99FCC", "#9C8FC3", "#907EBB", "#836DB2", "#775DAA", "#6A4CA1", "#5E3C99"))

p

p + theme(axis.title.x =element_text(size=14, family="serif", color = "black", hjust=0.5), axis.title.y=element_text(size=14,family="serif", color = "black", hjust=0.5),axis.text=element_text(size=14,family="serif", color = "black", hjust=0.5)) + guides(fill=FALSE)










mydata <- RS %>% filter(Vegetation == "shrublands" & ED == "0")
glimpse(mydata, width = 40)

#split into training (70%) and testing set (70%)

sample_split <- sample.split(Y = mydata$RS, SplitRatio = 0.7)
train_set <- subset(x = mydata, sample_split == TRUE)
test_set <- subset(x = mydata, sample_split == FALSE)


#define predictor and response variables in training dataset
y_train <- train_set$RS
glimpse(y_train, width = 40)
x_train <- train_set %>% select(1:21)
glimpse(x_train, width = 40)


y_test <- test_set$RS
glimpse(y_test, width = 40)
x_test <- test_set %>% select(1:21)
glimpse(x_test, width = 40)


xgb_train = xgb.DMatrix(as.matrix(sapply(x_train, as.numeric)), label=y_train)
xgb_test = xgb.DMatrix(as.matrix(sapply(x_test, as.numeric)), label=y_test)

watchlist = list(train=xgb_train, test=xgb_test)

model = xgb.train(data = xgb_train, max.depth = 3, watchlist=watchlist, nrounds = 70)

final = xgboost(data = xgb_train, max.depth = 3, nrounds = 56, verbose = 0)

final


importance_matrix <- xgb.importance(feature_names = colnames(xgb_train), model = final)
importance_matrix

xgb.plot.importance(importance_matrix)


data<-as.data.frame(importance_matrix)

coul <- brewer.pal(4, "PuOr") 
coul <- colorRampPalette(coul)(21)


p<-ggplot(data=data,mapping=aes(x=reorder(Feature,Gain),y=Gain/8.725988e-01,fill=Feature)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + coord_flip() + ylab("Variable relative importance") + theme_bw() + scale_fill_manual(values=c("#E66101","#E96E0F", "#EC7B1E", "#F0882D", "#F3953B", "#F7A24A", "#FAAF59", "#F9B768", "#EEB579", "#E2B389", "#E2B389", "#D7B19A" , "#CCAFAB",  "#C0ADBB", "#B5ABCC", "#A99FCC", "#9C8FC3", "#907EBB", "#836DB2", "#775DAA", "#6A4CA1", "#5E3C99"))

p





mydata <- RS %>% filter(Vegetation == "shrublands" & ED == "1")
glimpse(mydata, width = 40)

#split into training (70%) and testing set (70%)

sample_split <- sample.split(Y = mydata$RS, SplitRatio = 0.7)
train_set <- subset(x = mydata, sample_split == TRUE)
test_set <- subset(x = mydata, sample_split == FALSE)


#define predictor and response variables in training dataset
y_train <- train_set$RS
glimpse(y_train, width = 40)
x_train <- train_set %>% select(1:21)
glimpse(x_train, width = 40)


y_test <- test_set$RS
glimpse(y_test, width = 40)
x_test <- test_set %>% select(1:21)
glimpse(x_test, width = 40)


xgb_train = xgb.DMatrix(as.matrix(sapply(x_train, as.numeric)), label=y_train)
xgb_test = xgb.DMatrix(as.matrix(sapply(x_test, as.numeric)), label=y_test)

watchlist = list(train=xgb_train, test=xgb_test)

model = xgb.train(data = xgb_train, max.depth = 3, watchlist=watchlist, nrounds = 70)

final = xgboost(data = xgb_train, max.depth = 3, nrounds = 56, verbose = 0)

final


importance_matrix <- xgb.importance(feature_names = colnames(xgb_train), model = final)
importance_matrix

xgb.plot.importance(importance_matrix)


data<-as.data.frame(importance_matrix)

coul <- brewer.pal(4, "PuOr") 
coul <- colorRampPalette(coul)(21)


p<-ggplot(data=data,mapping=aes(x=reorder(Feature,Gain),y=Gain/4.858600e-01,fill=Feature)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + geom_bar(stat = 'identity',width = 0.8,position=position_dodge(0.7)) + coord_flip() + ylab("Variable relative importance") + theme_bw() + scale_fill_manual(values=c("#E66101","#E96E0F", "#EC7B1E", "#F0882D", "#F3953B", "#F7A24A", "#FAAF59", "#F9B768", "#EEB579", "#E2B389", "#E2B389", "#D7B19A" , "#CCAFAB",  "#C0ADBB", "#B5ABCC", "#A99FCC", "#9C8FC3", "#907EBB", "#836DB2", "#775DAA", "#6A4CA1", "#5E3C99"))

p















































