##Using SDRB Soil Respiration Dataset to Validate RS Remote Sensing Products
install.packages("dplyr")
install.packages("ggplot2")
install.packages("plotluck")
install.packages("psych")
install.packages("ggthemes")
install.packages("tidyverse")
install.packages("Rmisc")
install.packages("readr")
install.packages("ggsci")
install.packages("gridExtra")
install.packages("ggpmisc")
install.packages("ggpubr")
library(dplyr)
library(ggplot2)
library(plotluck)
library(psych)
library(ggthemes)
library(tidyverse)
library(Rmisc)
library(readr)
library(ggsci)
library(gridExtra)
library(ggpmisc)
library(ggpubr)
RS <- read_csv("E:\\RP\\SRDB dataset and RS soil respiration.csv")
glimpse(RS, width = 40)

p <- ggplot(RS, aes(x = RS_SRDB, y = RS_remote)) + geom_point(size=1.5,alpha=0.3,color="#6baed6") + geom_smooth(method = "lm", formula = y~x, color = "#756bb1", fill = "#cbc9e2") + theme_bw() + theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())
ggsave("SDRB土壤呼吸数据集与RS遥感数据验证.tiff",width=80, height=80, units="mm", dpi=800)
p+stat_poly_eq(aes(label=..eq.label..),formula = y~x,parse=T,size=4)+ stat_cor(label.y=0.9,size=4)



mydata <- RS %>% filter(Ecosystem_type == "Agriculture")
glimpse(mydata, width = 40)

p <- ggplot(mydata, aes(x = RS_SRDB, y = RS_remote)) + geom_point(size=1.5,alpha=0.3,color="#6baed6") + geom_smooth(method = "lm", formula = y~x, color = "#756bb1", fill = "#cbc9e2") + theme_bw() + theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())

p

ggsave("SDRB土壤呼吸数据集与RS遥感数据验证_农田.tiff",width=80, height=80, units="mm", dpi=800)

p+stat_poly_eq(aes(label=..eq.label..),formula = y~x,parse=T,size=4)+ stat_cor(label.y=0.9,size=4)





mydata <- RS %>% filter(Ecosystem_type == "Forest")
glimpse(mydata, width = 40)

p <- ggplot(mydata, aes(x = RS_SRDB, y = RS_remote)) + geom_point(size=1.5,alpha=0.3,color="#6baed6") + geom_smooth(method = "lm", formula = y~x, color = "#756bb1", fill = "#cbc9e2") + theme_bw() + theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())

p

ggsave("SDRB土壤呼吸数据集与RS遥感数据验证_森林.tiff",width=80, height=80, units="mm", dpi=800)

p+stat_poly_eq(aes(label=..eq.label..),formula = y~x,parse=T,size=4)+ stat_cor(label.y=0.9,size=4)




mydata <- RS %>% filter(Ecosystem_type == "Grassland")
glimpse(mydata, width = 40)

p <- ggplot(mydata, aes(x = RS_SRDB, y = RS_remote)) + geom_point(size=1.5,alpha=0.3,color="#6baed6") + geom_smooth(method = "lm", formula = y~x, color = "#756bb1", fill = "#cbc9e2") + theme_bw() + theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())

p

ggsave("SDRB土壤呼吸数据集与RS遥感数据验证_草地.tiff",width=80, height=80, units="mm", dpi=800)

p+stat_poly_eq(aes(label=..eq.label..),formula = y~x,parse=T,size=4)+ stat_cor(label.y=0.9,size=4)




















