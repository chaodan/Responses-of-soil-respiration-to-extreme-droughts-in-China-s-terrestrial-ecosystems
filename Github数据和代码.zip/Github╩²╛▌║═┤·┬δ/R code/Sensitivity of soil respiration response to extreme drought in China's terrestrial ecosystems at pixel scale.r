setwd("D:/SM")
fpath<-"D:\\SM\\datasamplenew.csv"
df<-read.csv(fpath)


test<-head(df)

retSRP<-function(formu,dt){
  myfit<-lm(formula=formu,data=dt)
  mysummary<-summary(myfit)

  mycoef<-as.data.frame(mysummary[[4]])
  Slope<-mycoef[1,1]
  
  RSquare<-mysummary[[8]]
  
  calcP<-mysummary$fstatistic
  PValue<-pf(calcP[1],calcP[2],calcP[3],lower.tail = F)
  
  return(data.frame(Slope,RSquare,PValue))
  
}


batchSRP<-function(dt){
  formus<-"Y~X"
  Xs=paste("X",1:19,sep="")
  Ys=paste("Y",1:19,sep="")
  finaldf<-data.frame()
  for(i in 1:nrow(dt)){
    #Yt为第i行Y1~Y19列数据转置后数组
    Yt<-t(dt[i,c(paste("Y",1:19,sep=""))])
    #Yf为Yt转换后的data.frame
    Yf<-as.data.frame(Yt)
    names(Yf)<-c("Y")
    #Xt为第i行X1~X19列数据转置后数组
    Xt<-t(dt[i,c(paste("X",1:19,sep=""))])
    #Xf为Xt转换后的data.frame
    Xf<-as.data.frame(Xt)
    names(Xf)<-c("X")
    # 将data.frame X与Y横向合并生成df数据集
    df<-cbind(Xf,Yf)
    # 调用上面定义的retSPR函数
    retdf<-retSRP(formus,df)
    # 将第i行数据的输出结果向下黏贴
    finaldf<-rbind(finaldf,retdf)
  }
  
  return(finaldf)
}

result<-batchSRP(df)
result<-cbind(df$BH,result)
names(result)[1]<-"RowNum"
write.csv(result,file="Result.csv",row.names = FALSE)
